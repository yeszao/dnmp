#pragma once

int yasd_api_module_init(int module_number);
